# Tawasol backend contract

هذه الواجهة مصممة لتعمل مع Backend حقيقي عبر REST/WebSocket. لا تضع أسرار المزودين داخل Frontend.

## الخدمات المقترحة
- Auth: phone/email, password hashing, refresh tokens, 2FA, recovery, sessions.
- Social: users, follows, friends, posts, comments, reactions, stories, saves, mutes.
- Messaging: WebSocket/Realtime, media upload, disappearing messages, voice/video signaling.
- Live: LiveKit/WebRTC tokens, rooms, gifts, PK, analytics.
- Commerce: stores, products, inventory, orders, coupons, landing pages.
- Ads: campaigns, audience, budget, duration, reach estimates, billing.
- Wallet: ledger, gifts, commissions, referrals, withdrawals, fraud review.
- AI: server-side provider gateway, moderation, merchant assistant.
- Security: rate limits, WAF, malware/link checks, moderation queues, audit logs.
- Admin: health, incidents, workers, alerts, financial reports and emergency controls.

## Example routes
POST /api/auth/register
POST /api/auth/login
POST /api/auth/2fa/verify
GET  /api/feed
POST /api/posts
DELETE /api/posts/:id
GET  /api/messages/:conversationId
POST /api/messages
POST /api/stores
POST /api/products
POST /api/campaigns/estimate
POST /api/campaigns
GET  /api/analytics/overview
GET  /api/referrals/me
POST /api/withdrawals
GET  /api/admin/health
POST /api/admin/panic

For production, use a real database, object storage, queue/worker system, secrets manager, monitoring, backups and CI/CD. The 100K worker target is an autoscaling capacity goal, not 100K processes running permanently.

## Workers
تشغيل عامل المراجعة:
`node backend/src/workers/moderation-worker.js`

في الإنتاج شغّل العمال كخدمة مستقلة وراقب Redis/BullMQ. لا تعتمد على عملية API واحدة لتشغيل كل الأعمال الثقيلة.
